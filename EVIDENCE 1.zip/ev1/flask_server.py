from flask import Flask, jsonify, request
import threading
import main 

app = Flask(__name__)
simulation_thread = None
simulation_running = False

def run_simulation():
    main.main()

@app.route('/start', methods=['POST'])
def start_simulation():
    global simulation_thread, simulation_running
    if not simulation_running:
        simulation_thread = threading.Thread(target=run_simulation)
        simulation_thread.start()
        simulation_running = True
        return jsonify({'status': 'Simulation started'})
    return jsonify({'status': 'Simulation already running'})

@app.route('/stop', methods=['POST'])
def stop_simulation():
    global simulation_running
    if simulation_running:
        main.simStop()
        simulation_running = False
        return jsonify({'status': 'Simulation stopped'})
    return jsonify({'status': 'Simulation not running'})

@app.route('/status', methods=['GET'])
def status():
    return jsonify({'running': simulation_running})

@app.route('/step', methods=['POST'])
def step_simulation():
    if simulation_running:
        step_count = main.step()
        return jsonify({'status': 'Step executed', 'step_count': step_count})
    return jsonify({'status': 'Simulation not running'})

if __name__ == '__main__':
    app.run()