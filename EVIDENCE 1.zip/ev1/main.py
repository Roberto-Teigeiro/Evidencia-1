import pygame
import random
import numpy as np
from enum import Enum
import time

# Constants
GRID_SIZE = 40
COLS = 15
ROWS = 15
WINDOW_WIDTH = COLS * GRID_SIZE
WINDOW_HEIGHT = ROWS * GRID_SIZE
NUM_ROBOTS = 5
NUM_OBJECTS = 20
MAX_STACK_SIZE = 5  # Maximum items per stack
SORTING_CELLS = [(0, i) for i in range(5)]  # First row, columns 0-4

class Direction(Enum):
    NORTH = 0
    EAST = 1
    SOUTH = 2
    WEST = 3

class Robot:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.direction = Direction.NORTH
        self.carrying = None
        self.color = (random.randint(100,255), random.randint(100,255), random.randint(100,255))
        self.target_x = None
        self.target_y = None
    
    def rotate(self, clockwise=True):
        if clockwise:
            self.direction = Direction((self.direction.value + 1) % 4)
        else:
            self.direction = Direction((self.direction.value - 1) % 4)
        # Add small delay to prevent too rapid rotation
    
    def move_forward(self, grid):
        next_x, next_y = self.get_forward_position()
        if 0 <= next_x < COLS and 0 <= next_y < ROWS and not grid[next_y][next_x]:
            grid[self.y][self.x] = None
            self.x, self.y = next_x, next_y
            grid[self.y][self.x] = self
            return True
        return False
    
    def get_forward_position(self):
        if self.direction == Direction.NORTH:
            return self.x, self.y - 1
        elif self.direction == Direction.EAST:
            return self.x + 1, self.y
        elif self.direction == Direction.SOUTH:
            return self.x, self.y + 1
        else:  # WEST
            return self.x - 1, self.y

    def pick_up_object(self, grid):
        next_x, next_y = self.get_forward_position()
        if (0 <= next_x < COLS and 0 <= next_y < ROWS and 
            isinstance(grid[next_y][next_x], WarehouseObject)):
            self.carrying = grid[next_y][next_x]
            # Keep the entire stack when picking up
            grid[next_y][next_x] = None
            return True
        return False

    def drop_object(self, grid, objects):
        if not self.carrying:
            return False
        next_x, next_y = self.get_forward_position()
        if 0 <= next_x < COLS and 0 <= next_y < ROWS:
            # Check if destination has a robot
            if isinstance(grid[next_y][next_x], Robot):
                return False
            
            if not grid[next_y][next_x]:
                # Place object in empty cell
                grid[next_y][next_x] = self.carrying
                self.carrying.x, self.carrying.y = next_x, next_y
                if self.carrying not in objects:
                    objects.append(self.carrying)
            elif isinstance(grid[next_y][next_x], WarehouseObject):
                # Stack on existing object
                grid[next_y][next_x].stack_size += self.carrying.stack_size
                if self.carrying in objects and self.carrying != grid[next_y][next_x]:
                    objects.remove(self.carrying)
            self.carrying = None
            return True
        return False

    def find_nearest_sorting_cell(self, grid):
        best_distance = float('inf')
        best_cell = None
        
        for y, x in SORTING_CELLS:
            cell = grid[y][x]
            if not cell or (isinstance(cell, WarehouseObject) and cell.stack_size < MAX_STACK_SIZE):
                # Calculate Manhattan distance
                distance = abs(self.x - x) + abs(self.y - (y + 1))
                if distance < best_distance:
                    best_distance = distance
                    best_cell = (x, y)
        
        return best_cell

    def move_towards(self, target_x, target_y, grid):
        if self.x == target_x and self.y == target_y:
            return True

        # Calculate direction to target
        dx = target_x - self.x
        dy = target_y - self.y

        # Try primary movement direction
        if abs(dx) > abs(dy):
            # Try horizontal movement
            if not self._try_move_horizontal(dx, grid):
                # If horizontal blocked, try vertical
                if not self._try_move_vertical(dy, grid):
                    # If both blocked, rotate randomly to break potential loops
                    self.rotate(random.choice([True, False]))
        else:
            # Try vertical movement
            if not self._try_move_vertical(dy, grid):
                # If vertical blocked, try horizontal
                if not self._try_move_horizontal(dx, grid):
                    # If both blocked, rotate randomly to break potential loops
                    self.rotate(random.choice([True, False]))
        
        return False

    def _try_move_horizontal(self, dx, grid):
        desired_direction = Direction.EAST if dx > 0 else Direction.WEST
        if self.direction != desired_direction:
            self.rotate(self.direction.value < desired_direction.value)
        return self.move_forward(grid)

    def _try_move_vertical(self, dy, grid):
        desired_direction = Direction.SOUTH if dy > 0 else Direction.NORTH
        if self.direction != desired_direction:
            self.rotate(self.direction.value < desired_direction.value)
        return self.move_forward(grid)

class WarehouseObject:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.color = (200, 100, 100)
        self.stack_size = 1  # Track stack size

class Warehouse:
    def __init__(self):
        self.grid = [[None for _ in range(COLS)] for _ in range(ROWS)]
        self.robots = []
        self.objects = []
        self.steps = 0  # Step counter
        self.initialize()
    def all_boxes_sorted(self):
        for obj in self.objects:
            if obj.y > 5:
                return False
        return True
    def initialize(self):
        # Place robots
        for _ in range(NUM_ROBOTS):
            while True:
                x, y = random.randint(0, COLS-1), random.randint(0, ROWS-1)
                if not self.grid[y][x]:
                    robot = Robot(x, y)
                    self.grid[y][x] = robot
                    self.robots.append(robot)
                    break
        
        # Place objects
        for _ in range(NUM_OBJECTS):
            while True:
                x, y = random.randint(0, COLS-1), random.randint(0, ROWS-1)
                if not self.grid[y][x]:
                    obj = WarehouseObject(x, y)
                    self.grid[y][x] = obj
                    self.objects.append(obj)
                    break

    def update(self):
            for robot in self.robots:
                if robot.carrying:
                    # Find nearest available sorting cell
                    target = robot.find_nearest_sorting_cell(self.grid)
                    if target:
                        target_x, target_y = target
                        
                        # If robot is in position to drop (one cell below target)
                        if robot.x == target_x and robot.y == target_y + 1:
                            # Face north and drop
                            while robot.direction != Direction.NORTH:
                                robot.rotate()
                            robot.drop_object(self.grid, self.objects)
                        else:
                            # Move towards position below target
                            robot.move_towards(target_x, target_y + 1, self.grid)
                else:
                    # Random behavior when not carrying
                    action = random.random()
                    if action < 0.2:  # Increase chance to pick up
                        robot.pick_up_object(self.grid)
                    elif action < 0.6:
                        robot.move_forward(self.grid)
                    else:
                        robot.rotate(random.choice([True, False]))

                # Reset target if no longer carrying
                if not robot.carrying:
                    robot.target_x = None
                    robot.target_y = None
            
            # Validate grid periodically
            if random.random() < 0.1:  # 10% chance each update
                self.validate_grid()
            
            # Increment step counter
            self.steps += 1

            # Check if all boxes are sorted
            if self.all_boxes_sorted():
                self.stop_simulation()

    def stop_simulation(self):
            global running
            running = False
            print(f"Simulation stopped after {self.steps} steps.")
    def check_objects(self):
        # Remove any None or invalid objects
        self.objects = [obj for obj in self.objects if obj is not None]
        # Ensure all grid objects are tracked
        for y in range(ROWS):
            for x in range(COLS):
                if isinstance(self.grid[y][x], WarehouseObject):
                    if self.grid[y][x] not in self.objects:
                        self.objects.append(self.grid[y][x])

    def validate_grid(self):
        for y in range(ROWS):
            for x in range(COLS):
                cell = self.grid[y][x]
                if isinstance(cell, WarehouseObject):
                    if cell not in self.objects:
                        self.objects.append(cell)
                elif isinstance(cell, Robot):
                    if cell not in self.robots:
                        self.robots.append(cell)
# Global warehouse instance
warehouse = None

def step():
    global warehouse
    if warehouse:
        warehouse.update()
        return warehouse.steps
    return None
def main():
    global warehouse, running
    pygame.init()
    pygame.font.init()
    font = pygame.font.SysFont('Arial', 20)
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Warehouse Robots")
    clock = pygame.time.Clock()
    
    warehouse = Warehouse()
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        warehouse.update()
        
        # Draw
        screen.fill((255, 255, 255))
        
        # Draw grid
        for i in range(COLS):
            for j in range(ROWS):
                pygame.draw.rect(screen, (200, 200, 200), 
                               (i*GRID_SIZE, j*GRID_SIZE, GRID_SIZE, GRID_SIZE), 1)
        
        # Draw objects and robots
        for y in range(ROWS):
            for x in range(COLS):
                item = warehouse.grid[y][x]
                if isinstance(item, Robot):
                    # Draw robot
                    pygame.draw.circle(screen, item.color,
                                    (x*GRID_SIZE + GRID_SIZE//2, 
                                     y*GRID_SIZE + GRID_SIZE//2), 
                                    GRID_SIZE//3)
                    # Draw carried object if any
                    if item.carrying:
                        pygame.draw.rect(screen, item.carrying.color,
                                       (x*GRID_SIZE + GRID_SIZE//3,
                                        y*GRID_SIZE + GRID_SIZE//3,
                                        GRID_SIZE//3, GRID_SIZE//3))
                elif isinstance(item, WarehouseObject):
                    # Darker shade for higher stacks
                    base_color = item.color[0], item.color[1], max(0, item.color[2] - (item.stack_size * 20))
                    pygame.draw.rect(screen, base_color,
                                    (x*GRID_SIZE + GRID_SIZE//4,
                                     y*GRID_SIZE + GRID_SIZE//4,
                                     GRID_SIZE//2, GRID_SIZE//2))
                    # Draw stack size
                    if item.stack_size > 1:
                        text = font.render(str(item.stack_size), True, (0, 0, 0))
                        screen.blit(text, (x*GRID_SIZE + GRID_SIZE//2 - 5,
                                          y*GRID_SIZE + GRID_SIZE//2 - 8))
        
        pygame.display.flip()
        clock.tick(30)
    
    pygame.quit()

if __name__ == "__main__":
    main()